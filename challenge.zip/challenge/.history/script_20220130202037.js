'use strict';

function wizardNavigation() {
    var v = $("#form").validate({
        rules: {
            bf_totalGuests: {
                required: true
            },
            bf_date: {
                required: true
            },
            bf_time: {
                required: true
            },
            bf_hours: {
                required: true
            },
            bf_fullname: {
                required: true
            },
            bf_email: {
                required: true,
                email: true
            }

        },
        errorElement: "span",
        errorClass: "error",
        errorPlacement: function(error, element) {
            error.insertBefore(element);
        }
    });

    $(".next-btn1").click(function() {
        if (v.form()) {
            $(".step-content").hide();
            $("#step2").fadeIn(1000);
            $('.wizard-navigation li').removeClass('active');
            $('.wizard-navigation li:nth-child(2)').addClass('active');
        }
    });

    $(".next-btn2").click(function() {
        if (v.form()) {
            $(".step-content").hide();
            $("#step3").fadeIn(1000);
            $('.wizard-navigation li').removeClass('active');
            $('.wizard-navigation li:nth-child(3)').addClass('active');
        }
    });

    $(".prev-btn1").click(function() {
        if (v.form()) {
            $(".step-content").hide();
            $("#step1").fadeIn(1000);
            $('.wizard-navigation li').removeClass('active');
            $('.wizard-navigation li:nth-child(1)').addClass('active');
        }
    });

    $(".prev-btn2").click(function() {
        if (v.form()) {
            $(".step-content").hide();
            $("#step2").fadeIn(1000);
            $('.wizard-navigation li').removeClass('active');
            $('.wizard-navigation li:nth-child(2)').addClass('active');
        }
    });

    $(".submit-btn").click(function() {
        if (v.form()) {
            $("#loader").show();
            setTimeout(function() {
                $("#booking-form").html("<h2>Your message was sent successfully. Thanks! We'll be in touch as soon as we can, which is usually like lightning (Unless we're sailing or eating tacos!).</h2>");
            }, 1000);
            return false;
        }
    });
}
wizardNavigation();

function datePicker() {
    $(".datepicker").datepicker({ dateFormat: "yyyy-mm-dd" });
    console.log('test');
}

datePicker();

function handleClick() {
    $(".room").click(function() {
        if ($(this).hasClass("active")) {
            $(".room").removeClass("active");
        } else {
            $(".room").removeClass("active");
            $(this).addClass("active");
        }
    });

    $(".landscape").click(function() {
        if ($(this).hasClass("active")) {
            $(".landscape").removeClass("active");
        } else {
            $(".landscape").removeClass("active");
            $(this).addClass("active");
        }
    });
}
handleClick();