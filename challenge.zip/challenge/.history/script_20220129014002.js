'use strict';

let tabs = $('form > div');
tabs.filter(':not(:first)').hide();

let prev = $('.btn-prev');
let next = $('.btn-next');

tabs.find('input, textarea, select').on('keyup input', function(e) {
    $(this).removeClass('error');
});

// var form = $("#form");
// form.validate({
//     errorPlacement: function errorPlacement(error, element) { element.before(error); },
//     rules: {
//         confirm: {
//             equalTo: "#password"
//         }
//     }
// });

// form.children(".wizard-navigation").steps({
//     headerTag: ".deneme",
//     bodyTag: ".li",
//     transitionEffect: "slideLeft",
//     onStepChanging: function(event, currentIndex, newIndex) {
//         form.validate().settings.ignore = ":disabled,:hidden";
//         return form.valid();
//     },
//     onFinishing: function(event, currentIndex) {
//         form.validate().settings.ignore = ":disabled";
//         return form.valid();
//     },
//     onFinished: function(event, currentIndex) {
//         alert("Submitted!");
//     }
// });

// $(document).ready(function() {
//     $('#datepick').datepicker();
// });