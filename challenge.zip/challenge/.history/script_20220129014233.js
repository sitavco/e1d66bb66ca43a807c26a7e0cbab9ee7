'use strict';

let tabs = $('form > div');
tabs.filter(':not(:first)').hide();

let prev = $('.btn-prev');
let next = $('.btn-next');

tabs.find('input, textarea, select').on('keyup input', function(e) {
    $(this).removeClass('error');
});

next.on('click', function(e) {
    e.preventDefault();

    console.log('ss');

    let elems = $('.tab:visible input, .tab:visible textarea, .tab:visible select');
    let errors = false;
    elems.each(function() {
        if ($(this).is(':invalid')) {
            errors = true;
            $(this).addClass('error');
        }
    });

    if (!errors) {
        let nextTab = $('.tab:visible').next();
        if (nextTab.length == 0) {
            $('.tab').closest('form').submit(); // formu gönder
        } else {
            $('.tab:visible').hide();
            nextTab.show();
            nextTab.find('*:first').focus();
            if (nextTab.length > 0) {
                prev.removeAttr('disabled');
            }
            if ($('.tab:visible').index() + 1 == $('.tab').length) {
                next.text(next.data('submit'));
            } else {
                next.text(next.data('next'));
            }
        }
    } else {
        $('.tab:visible .error:first').focus();
    }

});

// var form = $("#form");
// form.validate({
//     errorPlacement: function errorPlacement(error, element) { element.before(error); },
//     rules: {
//         confirm: {
//             equalTo: "#password"
//         }
//     }
// });

// form.children(".wizard-navigation").steps({
//     headerTag: ".deneme",
//     bodyTag: ".li",
//     transitionEffect: "slideLeft",
//     onStepChanging: function(event, currentIndex, newIndex) {
//         form.validate().settings.ignore = ":disabled,:hidden";
//         return form.valid();
//     },
//     onFinishing: function(event, currentIndex) {
//         form.validate().settings.ignore = ":disabled";
//         return form.valid();
//     },
//     onFinished: function(event, currentIndex) {
//         alert("Submitted!");
//     }
// });

// $(document).ready(function() {
//     $('#datepick').datepicker();
// });